 #include <stdio.h>
 #include <stdlib.h>
 #include <unistd.h>
 #include <sys/types.h>
 #include <sys/stat.h>
 #include <fcntl.h>

 int main()
 {
 int x[2]={268435452,1};
 int fp;
 fp=open("/dev/adder_d",O_WRONLY|O_CREAT);
 if(fp<0)
 printf("open /proc/myled for write\n");
 ioctl(fp,0,x);
 sleep(2);
 close(fp);
 printf("\nx0= %d\n",x[0]);
 printf("x1= %d\n",x[1]);
 return 0;
}



