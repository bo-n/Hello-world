#include "adder.h"

void adder(int a, int b, int *c)
{
	*c = a + b;
}
