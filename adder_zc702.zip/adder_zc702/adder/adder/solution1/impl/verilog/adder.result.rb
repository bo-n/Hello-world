$Footmark = "FPGA_Xilinx"
$Description = "by Vivado"


#=== Resource usage ===
$SLICE = "42"
$LUT = "128"
$FF = "179"
$DSP = "0"
$BRAM ="0"
$SRL ="0"
#=== Final timing ===
$TargetCP = "10.000"
$CP = "4.593"
