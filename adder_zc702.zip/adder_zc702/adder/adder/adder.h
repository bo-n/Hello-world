#ifndef ADDER_H
#define ADDER_H
void adder(int a, int b, int *c);
#endif
